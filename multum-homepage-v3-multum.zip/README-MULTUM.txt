MULTUM.AI edited index
Replace the repository's index.html with this file.
Keep the existing assets beside it:
bg-1.jpg, bg-2.jpg, bg-3.jpg,
bloom-bg-1.mp4, bloom-bg-2.mp4, bloom-bg-3.mp4.
